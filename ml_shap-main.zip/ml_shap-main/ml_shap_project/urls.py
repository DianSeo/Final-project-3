from django.contrib import admin
from django.urls import path, include
from django.shortcuts import render

# ✅ 홈(index.html) 렌더링
def home(request):
    return render(request, "index.html")

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', home, name='home'),                # 메인 페이지
    path('survey/', include('ml_app_survey.urls')),  # 설문 앱 연결
]
