from django.apps import AppConfig


class MlAppDiaryConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'ml_app_diary'
