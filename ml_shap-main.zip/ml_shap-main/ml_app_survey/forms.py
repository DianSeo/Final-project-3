from django import forms
import os, json

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MODEL_DIR = os.path.join(BASE_DIR, "ml")   # ← 추가
FEATURE_PATH = os.path.join(MODEL_DIR, "final_feature_order.json")
CODEBOOK_PATH = os.path.join(MODEL_DIR, "codebook_kor.json")

# 1️⃣ feature order 로드 (39개)
with open(FEATURE_PATH, "r", encoding="utf-8") as f:
    FEATURE_NAMES = json.load(f)

# 2️⃣ 한글 코드북 로드 (dict)
with open(CODEBOOK_PATH, "r", encoding="utf-8") as f:
    FEATURE_MAP_KOR = json.load(f)

LIKERT_CHOICES = [
    (1, '1 - 전혀 그렇지 않다'),
    (2, '2 - 그렇지 않다'),
    (3, '3 - 보통이다'),
    (4, '4 - 그렇다'),
    (5, '5 - 매우 그렇다'),
]

class StressSurveyForm(forms.Form):
    # 39개 문항 생성
    for code in FEATURE_NAMES:
        locals()[code] = forms.ChoiceField(
            label=FEATURE_MAP_KOR.get(code, code),   # ← 한글 문항명
            choices=LIKERT_CHOICES,
            widget=forms.RadioSelect,
            required=True
        )
    del code
