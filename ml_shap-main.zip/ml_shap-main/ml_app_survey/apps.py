from django.apps import AppConfig


class MlAppSurveyConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'ml_app_survey'
