import os
import pickle
import json
import base64
from io import BytesIO
import numpy as np
import shap
import pandas as pd

import matplotlib
matplotlib.use("Agg")  # 서버(헤드리스)에서 이미지 생성 가능하게 함
import matplotlib.pyplot as plt

# 🔥 한글 폰트 설정
plt.rcParams['font.family'] = 'Malgun Gothic'
plt.rcParams['axes.unicode_minus'] = False


# ----------------------------------------------------
# 1) 모델 파일 로드 함수
# ----------------------------------------------------
def load_objects():
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))
    MODEL_DIR = os.path.join(BASE_DIR, "ml")

    PATH_SCALER = os.path.join(MODEL_DIR, "scaler.pkl")
    PATH_VOTING = os.path.join(MODEL_DIR, "voting_clf_soft.pkl")
    PATH_LR = os.path.join(MODEL_DIR, "logistic_regression_model.pkl")
    PATH_FEATURES = os.path.join(MODEL_DIR, "final_feature_order.json")
    PATH_CODEBOOK = os.path.join(MODEL_DIR, "codebook_kor.json")

    scaler = pickle.load(open(PATH_SCALER, "rb"))
    voting_model = pickle.load(open(PATH_VOTING, "rb"))
    lr_model = pickle.load(open(PATH_LR, "rb"))

    feature_order = json.load(open(PATH_FEATURES, "r", encoding="utf-8"))
    feature_map_kor = json.load(open(PATH_CODEBOOK, "r", encoding="utf-8"))

    return scaler, voting_model, lr_model, feature_order, feature_map_kor


# ----------------------------------------------------
# 2) 예측 + SHAP Top5
# ----------------------------------------------------
def getPrediction(*user_values):

    scaler, voting_model, lr_model, feature_order, feature_map_kor = load_objects()

    # 입력 정리
    X_input = np.array(user_values).reshape(1, -1)
    X_scaled = scaler.transform(X_input)

    # ------------------------------------------------
    # 🔥 예측 (Soft Voting)
    # ------------------------------------------------
    y_pred = voting_model.predict(X_scaled)

    # # pred도 반대로 하고 싶으면 (선택)
    # y_pred = (prob_high < 0.5).astype(int)  # 낮음=1, 높음=0 로 반전

    # Soft Voting 예측 (결과 반대로 뒤집기)
    prob_high = voting_model.predict_proba(X_scaled)[:, 1]
    y_prob = (1 - prob_high) * 100  # 🔥 스트레스 낮음 확률로 변환


    # pred도 반대로 하고 싶으면 (선택)
    y_pred = (prob_high < 0.5).astype(int)  # 낮음=1, 높음=0 로 반전

    # ------------------------------------------------
    # 🔥 SHAP (Logistic Regression 기반)
    # ------------------------------------------------
    shap_img = None

    try:
        explainer = shap.LinearExplainer(
            lr_model,
            np.zeros((1, X_scaled.shape[1]))    # baseline
        )

        shap_values = explainer.shap_values(X_scaled)[0]
        shap_values = np.array(shap_values, dtype=float)

        # 양수 SHAP만 선택 (스트레스 증가 요인)
        positive_idx = [i for i, val in enumerate(shap_values) if val > 0]
        pos_vals = shap_values[positive_idx]

        # 한국어 문항명 매핑
        pos_codes = [feature_order[i] for i in positive_idx]
        pos_labels = [feature_map_kor.get(code, code) for code in pos_codes]

        if len(pos_vals) == 0:
            raise Exception("양수 SHAP 값이 없습니다.")

        # SHAP 높은 순으로 내림차순 정렬
        sorted_idx = np.argsort(pos_vals)[::-1]

        # TOP 5
        top_idx = sorted_idx[:5]
        top_values = [float(pos_vals[i]) for i in top_idx]
        top_features = [pos_labels[i] for i in top_idx]

        # ------------------------------------------------
        # 🔥 바 차트 생성
        # ------------------------------------------------
        plt.figure(figsize=(10, 4))
        plt.barh(top_features, top_values, color="#3b7f6a")

        plt.gca().invert_yaxis()  # 큰 값이 위로

        # 글자 크기 조정
        plt.yticks(fontsize=12)
        plt.xticks(fontsize=12)

        # 라벨 왼쪽 정렬
        plt.gca().set_yticklabels(top_features, ha='left')

        # 여백 확보
        plt.subplots_adjust(left=0.32)

        # 제목
        plt.title("STRESS TOP 5", fontsize=15, pad=10)
        plt.xlabel("Stress Impact Score", fontsize=12)

        # 저장
        buf = BytesIO()
        plt.savefig(buf, format="png", bbox_inches="tight")
        plt.close()

        shap_img = base64.b64encode(buf.getvalue()).decode("utf-8")

    except Exception as e:
        print("⚠ SHAP 생성 오류:", e)
        shap_img = None

    return y_pred, y_prob, shap_img
