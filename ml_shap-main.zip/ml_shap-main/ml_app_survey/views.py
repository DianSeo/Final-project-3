from django.shortcuts import render, redirect
from django.utils.safestring import mark_safe
from .forms import StressSurveyForm
from .predict import getPrediction


def survey_view(request):
    if request.method == "POST":
        form = StressSurveyForm(request.POST)

        if form.is_valid():
            # 1) 설문 값 저장 → 세션에 저장
            user_values = [int(v) for v in form.cleaned_data.values()]
            request.session["survey_inputs"] = user_values

            # 2) 결과 페이지로 이동 (URL 변경됨)
            return redirect("survey_result")

    else:
        form = StressSurveyForm()

    return render(request, "ml_app_survey/survey.html", {"form": form})



def survey_result_view(request):
    # 3) 세션에서 값 가져오기
    user_values = request.session.get("survey_inputs")

    if not user_values:
        return redirect("survey")  # 설문 없이 접근 막기

    # 4) 예측 수행
    y_pred, prob, shap_img = getPrediction(*user_values)

    result_text = "스트레스 높음 🚨" if int(y_pred[0]) == 1 else "스트레스 낮음 😊"
    prob_percent = round(float(prob[0]), 2)

    return render(request, "ml_app_survey/survey_result.html", {
        "result_text": result_text,
        "prob": prob_percent,
        "shap_img": shap_img,
    })
