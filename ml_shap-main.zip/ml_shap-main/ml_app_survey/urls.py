from django.urls import path
from . import views

urlpatterns = [
    path("", views.survey_view, name="survey"),               # /survey/
    path("result/", views.survey_result_view, name="survey_result"),  # /survey/result/
]
