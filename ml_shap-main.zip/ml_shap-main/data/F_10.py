#%%
import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier, AdaBoostClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.naive_bayes import GaussianNB
import joblib
import pickle
import os
from datetime import datetime

print("="*80)
print("🔥 번아웃 예측 모델 - joblib & pickle 완전 가이드")
print("="*80)

#%%
# ============================================
# 🔴 구간 1: 데이터 로드 및 전처리
# ============================================
print("\n" + "="*80)
print("🔴 구간 1: 데이터 로드 및 전처리")
print("="*80)

# CSV 파일 로드
CSV_PATH = "e:\\dataset.csv"

if os.path.exists(CSV_PATH):
    df = pd.read_csv(CSV_PATH)
    print(f"✅ 데이터 로드 완료: {CSV_PATH}")
    print(f"   - 행 개수: {len(df)}")
    print(f"   - 열 개수: {len(df.columns)}")
else:
    print(f"⚠️  파일이 없습니다: {CSV_PATH}")
    print("   샘플 데이터를 생성합니다...")
    
    # 샘플 데이터 생성
    np.random.seed(42)
    n_samples = 300
    
    # OS1~OS41 항목 생성
    data = {}
    for i in range(1, 42):
        data[f'OS{i}'] = np.random.randint(1, 6, n_samples)
    
    # JS 항목들 추가 (예시)
    for col in ['JS2', 'JS3', 'JS5', 'JS10', 'JS11', 'JS13', 'JS16', 'JS18']:
        data[col] = np.random.randint(1, 6, n_samples)
    
    df = pd.DataFrame(data)
    print(f"✅ 샘플 데이터 생성 완료: {len(df)}행")

# ============================================
# 직무 스트레스 합계 계산
# ============================================
print("\n📊 직무 스트레스 합계 계산 중...")

stress_columns = [f'OS{i}' for i in range(1, 42)]
df['Occupational_Stress_Sum'] = df[stress_columns].sum(axis=1)
print(f"   ✅ 직무 스트레스 합계 생성")

# ============================================
# 정규화 (MinMaxScaler)
# ============================================
print("\n📐 데이터 정규화 중...")

scaler = MinMaxScaler()
df['Occupational_Stress_Normalized'] = scaler.fit_transform(df[['Occupational_Stress_Sum']])
print(f"   ✅ MinMaxScaler로 정규화 완료")
print(f"   - 정규화 범위: [{df['Occupational_Stress_Normalized'].min():.3f}, {df['Occupational_Stress_Normalized'].max():.3f}]")

# ============================================
# 타겟 변수 생성 (0.5 기준 이진화)
# ============================================
print("\n🎯 타겟 변수 생성 중...")

df['Occupational_Stress_Target'] = df['Occupational_Stress_Normalized'].apply(
    lambda x: 0 if x <= 0.5 else 1
)

print(f"   ✅ 타겟 변수 생성 완료")
print(f"   - 클래스 0 (낮은 스트레스): {(df['Occupational_Stress_Target'] == 0).sum()}개")
print(f"   - 클래스 1 (높은 스트레스): {(df['Occupational_Stress_Target'] == 1).sum()}개")

# ============================================
# 불필요한 컬럼 제거
# ============================================
print("\n🗑️  불필요한 컬럼 제거 중...")

df_processed = df.drop(columns=stress_columns + ['Occupational_Stress_Sum', 'Occupational_Stress_Normalized'])
print(f"   ✅ OS1~OS41, 합계, 정규화 컬럼 제거 완료")
print(f"   - 남은 피처 개수: {len(df_processed.columns) - 1}")  # 타겟 제외


# ============================================
# 🟠 구간 2: Train/Test 데이터 분리
# ============================================
print("\n" + "="*80)
print("🟠 구간 2: Train/Test 데이터 분리")
print("="*80)

# X, y 분리
X = df_processed.drop(columns=['Occupational_Stress_Target'])
y = df_processed['Occupational_Stress_Target']

print(f"✅ X, y 분리 완료")
print(f"   - X shape: {X.shape}")
print(f"   - y shape: {y.shape}")

# Train/Test 분리 (80:20)
X_train, X_test, y_train, y_test = train_test_split(
    X, y, 
    test_size=0.2, 
    random_state=42, 
    stratify=y
)

print(f"\n✅ Train/Test 분리 완료")
print(f"   - X_train: {X_train.shape}")
print(f"   - X_test: {X_test.shape}")
print(f"   - y_train: {y_train.shape}")
print(f"   - y_test: {y_test.shape}")


# ============================================
# 🟡 구간 3: 여러 모델 학습
# ============================================
print("\n" + "="*80)
print("🟡 구간 3: 여러 모델 학습")
print("="*80)

# 모델들 정의
models = {
    'GaussianNB': GaussianNB(),
    'DecisionTree': DecisionTreeClassifier(random_state=42),
    'RandomForest': RandomForestClassifier(
        n_estimators=100,
        max_depth=10,
        random_state=42,
        n_jobs=-1
    ),
    'AdaBoost': AdaBoostClassifier(random_state=42)
}

# 학습된 모델 저장할 딕셔너리
trained_models = {}
model_scores = {}

# 각 모델 학습
for model_name, model in models.items():
    print(f"\n🚀 {model_name} 학습 중...")
    
    # 모델 학습
    model.fit(X_train, y_train)
    
    # 성능 평가
    train_score = model.score(X_train, y_train)
    test_score = model.score(X_test, y_test)
    
    # 저장
    trained_models[model_name] = model
    model_scores[model_name] = {
        'train_score': train_score,
        'test_score': test_score
    }
    
    print(f"   ✅ {model_name} 학습 완료")
    print(f"   - Train 정확도: {train_score:.4f}")
    print(f"   - Test 정확도: {test_score:.4f}")

# 최고 성능 모델 찾기
best_model_name = max(model_scores, key=lambda k: model_scores[k]['test_score'])
best_model = trained_models[best_model_name]
best_score = model_scores[best_model_name]['test_score']

print(f"\n🏆 최고 성능 모델: {best_model_name}")
print(f"   - Test 정확도: {best_score:.4f}")


# ============================================
# 🔵 구간 4: 모델 저장 (joblib 방법)
# ============================================
print("\n" + "="*80)
print("🔵 구간 4: 모델 저장 - joblib 방법 (권장!)")
print("="*80)

# 저장 디렉토리 생성
os.makedirs('../models', exist_ok=True)

# ==========================================
# 4-1. 최고 성능 모델만 저장 (간단한 방법)
# ==========================================
print("\n📦 [방법 1] 최고 성능 모델만 저장")

model_path = f'./models/{best_model_name}_model.pkl'
joblib.dump(best_model, model_path, compress=3)

file_size = os.path.getsize(model_path) / 1024
print(f"   ✅ joblib로 저장 완료: {model_path}")
print(f"   - 파일 크기: {file_size:.2f} KB")

# ==========================================
# 4-2. 모델 + 스케일러 함께 저장 (권장!)
# ==========================================
print("\n📦 [방법 2] 모델 + 스케일러 함께 저장 (권장!)")

pipeline = {
    'model': best_model,
    'model_name': best_model_name,
    'scaler': scaler,  # MinMaxScaler
    'feature_names': X_train.columns.tolist(),
    'train_score': model_scores[best_model_name]['train_score'],
    'test_score': model_scores[best_model_name]['test_score'],
    'trained_at': datetime.now().strftime("%Y-%m-%d %H:%M:%S")
}

pipeline_path = 'burnout_pipeline.pkl'
joblib.dump(pipeline, pipeline_path, compress=3)

file_size = os.path.getsize(pipeline_path) / 1024
print(f"   ✅ joblib로 저장 완료: {pipeline_path}")
print(f"   - 파일 크기: {file_size:.2f} KB")
print(f"   - 포함 내용: 모델, 스케일러, 피처명, 성능 지표")

# ==========================================
# 4-3. 모든 모델 저장
# ==========================================
print("\n📦 [방법 3] 모든 모델 저장")

all_models_path = '../models/all_models.pkl'
all_models_data = {
    'models': trained_models,
    'scores': model_scores,
    'scaler': scaler,
    'feature_names': X_train.columns.tolist(),
    'best_model': best_model_name
}

joblib.dump(all_models_data, all_models_path, compress=3)

file_size = os.path.getsize(all_models_path) / 1024
print(f"   ✅ joblib로 저장 완료: {all_models_path}")
print(f"   - 파일 크기: {file_size:.2f} KB")
print(f"   - 포함 모델: {', '.join(trained_models.keys())}")


# ============================================
# 🟣 구간 5: 모델 저장 (pickle 방법)
# ============================================
print("\n" + "="*80)
print("🟣 구간 5: 모델 저장 - pickle 방법")
print("="*80)

# ==========================================
# 5-1. pickle로 최고 성능 모델 저장
# ==========================================
print("\n📦 [방법 1] pickle로 모델 저장")

pickle_model_path = '../models/best_model_pickle.pkl'
with open(pickle_model_path, 'wb') as f:
    pickle.dump(best_model, f)

file_size = os.path.getsize(pickle_model_path) / 1024
print(f"   ✅ pickle로 저장 완료: {pickle_model_path}")
print(f"   - 파일 크기: {file_size:.2f} KB")

# ==========================================
# 5-2. pickle로 파이프라인 저장
# ==========================================
print("\n📦 [방법 2] pickle로 파이프라인 저장")

pickle_pipeline_path = '../models/burnout_pipeline_pickle.pkl'
with open(pickle_pipeline_path, 'wb') as f:
    pickle.dump(pipeline, f)

file_size = os.path.getsize(pickle_pipeline_path) / 1024
print(f"   ✅ pickle로 저장 완료: {pickle_pipeline_path}")
print(f"   - 파일 크기: {file_size:.2f} KB")


# ============================================
# 🟢 구간 6: 저장된 모델 로드 (joblib)
# ============================================
print("\n" + "="*80)
print("🟢 구간 6: 저장된 모델 로드 - joblib 방법")
print("="*80)

# ==========================================
# 6-1. 모델만 로드
# ==========================================
print("\n📥 [방법 1] 모델만 로드")

loaded_model = joblib.load(model_path)
print(f"   ✅ joblib로 로드 완료: {model_path}")

# 정확도 측정 (붓꽃 예제와 동일!)
score = loaded_model.score(X_test, y_test)
print(f"   - 정확도: {score:.3f}")

# ==========================================
# 6-2. 파이프라인 로드 (권장!)
# ==========================================
print("\n📥 [방법 2] 파이프라인 로드 (권장!)")

loaded_pipeline = joblib.load(pipeline_path)
print(f"   ✅ joblib로 로드 완료: {pipeline_path}")
print(f"   - 모델명: {loaded_pipeline['model_name']}")
print(f"   - 학습 일시: {loaded_pipeline['trained_at']}")
print(f"   - Test 정확도: {loaded_pipeline['test_score']:.4f}")

# 정확도 재측정
score = loaded_pipeline['model'].score(X_test, y_test)
print(f"   - 재측정 정확도: {score:.3f}")


# ============================================
# 🟤 구간 7: 저장된 모델 로드 (pickle)
# ============================================
print("\n" + "="*80)
print("🟤 구간 7: 저장된 모델 로드 - pickle 방법")
print("="*80)

# ==========================================
# 7-1. pickle로 모델 로드
# ==========================================
print("\n📥 [방법 1] pickle로 모델 로드")

with open(pickle_model_path, 'rb') as f:
    loaded_model_pickle = pickle.load(f)

print(f"   ✅ pickle로 로드 완료: {pickle_model_path}")

# 정확도 측정
score = loaded_model_pickle.score(X_test, y_test)
print(f"   - 정확도: {score:.3f}")

# ==========================================
# 7-2. pickle로 파이프라인 로드
# ==========================================
print("\n📥 [방법 2] pickle로 파이프라인 로드")

with open(pickle_pipeline_path, 'rb') as f:
    loaded_pipeline_pickle = pickle.load(f)

print(f"   ✅ pickle로 로드 완료: {pickle_pipeline_path}")

score = loaded_pipeline_pickle['model'].score(X_test, y_test)
print(f"   - 정확도: {score:.3f}")


# ============================================
# ⚫ 구간 8: 새로운 데이터 예측
# ============================================
print("\n" + "="*80)
print("⚫ 구간 8: 새로운 데이터 예측")
print("="*80)

# 새로운 환자 데이터 (예시)
print("\n🎯 새로운 환자 데이터로 예측...")

# 실제 피처명 사용 (JS 항목들)
new_patient_data = {}
for col in X_train.columns:
    new_patient_data[col] = [3]  # 중간값으로 설정

new_patient_df = pd.DataFrame(new_patient_data)

print(f"   - 입력 피처 수: {len(new_patient_df.columns)}")
print(f"   - 입력 데이터: {list(new_patient_df.iloc[0])[:5]}... (처음 5개)")

# 예측
prediction = loaded_pipeline['model'].predict(new_patient_df)[0]
probability = loaded_pipeline['model'].predict_proba(new_patient_df)[0]

print(f"\n📊 예측 결과:")
print(f"   - 스트레스 수준: {'높음 (1)' if prediction == 1 else '낮음 (0)'}")
print(f"   - 낮은 스트레스 확률: {probability[0]:.2%}")
print(f"   - 높은 스트레스 확률: {probability[1]:.2%}")


# ============================================
# ⚪ 구간 9: 파일 크기 비교
# ============================================
print("\n" + "="*80)
print("⚪ 구간 9: joblib vs pickle 파일 크기 비교")
print("="*80)

comparison = {
    'joblib (모델만)': model_path,
    'joblib (파이프라인)': pipeline_path,
    'pickle (모델만)': pickle_model_path,
    'pickle (파이프라인)': pickle_pipeline_path,
}

print("\n📊 파일 크기 비교:")
for name, path in comparison.items():
    size_kb = os.path.getsize(path) / 1024
    print(f"   {name:25s}: {size_kb:8.2f} KB")

print(f"\n💡 권장: joblib 파이프라인 방법")
print(f"   - 압축 지원 (compress 파라미터)")
print(f"   - numpy 배열 최적화")
print(f"   - scikit-learn 공식 권장")


# ============================================
# 🔟 구간 10: 저장된 파일 목록
# ============================================
print("\n" + "="*80)
print("🔟 구간 10: 저장된 파일 목록")
print("="*80)

print("\n📁 ./models/ 디렉토리:")
if os.path.exists('../models'):
    for filename in os.listdir('../models'):
        filepath = os.path.join('../models', filename)
        size_kb = os.path.getsize(filepath) / 1024
        print(f"   - {filename:35s} ({size_kb:8.2f} KB)")
else:
    print("   (디렉토리 없음)")


# ============================================
# 최종 요약
# ============================================
print("\n" + "="*80)
print("✅ 모든 작업 완료!")
print("="*80)

print(f"\n📦 저장된 파일:")
print(f"   1. joblib 모델: {model_path}")
print(f"   2. joblib 파이프라인: {pipeline_path}")
print(f"   3. pickle 모델: {pickle_model_path}")
print(f"   4. pickle 파이프라인: {pickle_pipeline_path}")

print(f"\n💡 Django에서 사용하기:")
print(f"   import joblib")
print(f"   pipeline = joblib.load('{pipeline_path}')")
print(f"   model = pipeline['model']")
print(f"   scaler = pipeline['scaler']")
print(f"   prediction = model.predict(new_data)")

print("\n" + "="*80)
# %%
